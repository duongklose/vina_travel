package com.example.vinatravel.ui.book_ticket.choose_departure_location;

public interface ChooseDepartureLocationContract {
    interface View{

    }

    interface Presenter{

    }
}
