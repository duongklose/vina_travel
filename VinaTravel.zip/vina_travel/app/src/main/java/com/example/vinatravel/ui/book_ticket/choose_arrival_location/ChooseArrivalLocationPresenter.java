package com.example.vinatravel.ui.book_ticket.choose_arrival_location;

public class ChooseArrivalLocationPresenter implements ChooseArrivalLocationContract.Presenter{
    private ChooseArrivalLocationContract.View view;

    public ChooseArrivalLocationPresenter(ChooseArrivalLocationContract.View view) {
        this.view = view;
    }
}
