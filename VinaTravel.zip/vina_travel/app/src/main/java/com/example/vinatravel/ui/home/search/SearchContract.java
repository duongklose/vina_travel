package com.example.vinatravel.ui.home.search;

public interface SearchContract {
    interface View{

    }

    interface  Presenter{
        void getListProvince();
    }
}
