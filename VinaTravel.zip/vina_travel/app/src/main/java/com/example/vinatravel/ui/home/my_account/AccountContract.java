package com.example.vinatravel.ui.home.my_account;

public interface AccountContract {
    interface View{

    }

    interface Presenter{

    }
}
