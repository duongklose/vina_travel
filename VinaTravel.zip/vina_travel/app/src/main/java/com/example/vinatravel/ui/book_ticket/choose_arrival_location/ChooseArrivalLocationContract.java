package com.example.vinatravel.ui.book_ticket.choose_arrival_location;

public interface ChooseArrivalLocationContract {
    interface View{

    }

    interface Presenter{

    }
}
