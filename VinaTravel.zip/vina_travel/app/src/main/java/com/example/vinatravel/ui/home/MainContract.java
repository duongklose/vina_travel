package com.example.vinatravel.ui.home;

public interface MainContract {
    interface View{

    }

    interface Presenter{

    }
}
